#!/bin/bash

gcc -o getrand getrand.c

