#!/bin/sh
gcc -o runsas runsas.c
gcc -o cantread cantread.c
