#!/bin/sh

gcc -o dinoui dinoui.c prime.c -lncurses -ltinfo
