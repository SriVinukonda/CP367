#!/bin/sh
gcc -o fmax fmax.c
gcc -o zmax zmax.c
gcc -o smax smax.c segv.c